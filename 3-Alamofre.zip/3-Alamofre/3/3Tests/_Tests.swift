//
//  _Tests.swift
//  3Tests
//
//  Created by zalkarbek on 2/10/24.
//

import Testing
@testable import _

struct _Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
