
struct NewsResponse: Codable {
    let status: String
    let totalResults: Int
    let results: [Article]
    let nextPage: String?

    enum CodingKeys: String, CodingKey {
        case status
        case totalResults = "total_results"
        case results
        case nextPage = "next_page"
    }
}
