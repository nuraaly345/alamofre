struct Article: Codable {
    let articleId: String?
    let title: String?
    let link: String?
    let keywords: [String]?
    let creator: [String]?
    let videoUrl: String?
    let description: String?
    let content: String?
    let pubDate: String?
    let pubDateTZ: String?
    let imageUrl: String?
    // Добавьте другие поля, если необходимо

    enum CodingKeys: String, CodingKey {
        case articleId = "article_id"
        case title
        case link
        case keywords
        case creator
        case videoUrl = "video_url"
        case description
        case content
        case pubDate
        case pubDateTZ
        case imageUrl = "image_url"
    }
}

