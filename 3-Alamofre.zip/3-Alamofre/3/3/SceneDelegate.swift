
// SceneDelegate.swift

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
   var window: UIWindow?

   func scene(_ scene: UIScene,
              willConnectTo session: UISceneSession,
              options connectionOptions: UIScene.ConnectionOptions) {

       guard let windowScene = (scene as? UIWindowScene) else { return }
       window = UIWindow(windowScene: windowScene)

       let tabBarController = UITabBarController()

       let allNewsVC = AllNewsViewController()
       let favoritesVC = FavoritesViewController()

       allNewsVC.tabBarItem = UITabBarItem(title: "All News", image: UIImage(systemName: "newspaper"), tag: 0)
       favoritesVC.tabBarItem = UITabBarItem(title: "Favorites", image: UIImage(systemName: "star"), tag: 1)

       let allNewsNav = UINavigationController(rootViewController: allNewsVC)
       let favoritesNav = UINavigationController(rootViewController: favoritesVC)

       tabBarController.viewControllers = [allNewsNav, favoritesNav]

       window?.rootViewController = tabBarController
       window?.makeKeyAndVisible()
   }
}

