import Foundation
import Alamofire

class FavoriteManager {
    static let shared = FavoriteManager()
    private var favorites: [Article] = []

    private init() {}

    // MARK: - Load Favorites
    func loadFavorites(completion: @escaping (Bool) -> Void) {
        let url = "https://newsdata.io/api/1/articles/favorites"

        AF.request(url, method: .get).responseDecodable(of: [Article].self) { response in
            switch response.result {
            case .success(let articles):
                self.favorites = articles
                completion(true)
            case .failure(let error):
                print("Failed to load favorites: \(error.localizedDescription)")
                completion(false)
            }
        }
    }

    // MARK: - Add to Favorites
    func addFavorite(_ article: Article, completion: @escaping (Bool) -> Void) {
        guard let articleId = article.articleId else {
            completion(false)
            return
        }

        let url = "https://yourapi.com/favorites"
        
        var parameters: [String: Any] = ["articleId": articleId]
        
        // Добавляем другие параметры, если они доступны
        if let title = article.title {
            parameters["title"] = title
        }
        
        if let link = article.link {
            parameters["link"] = link
        }

        AF.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default).response { response in
            switch response.result {
            case .success:
                self.favorites.append(article)
                completion(true)
            case .failure(let error):
                print("Failed to add favorite: \(error.localizedDescription)")
                completion(false)
            }
        }
    }

    // MARK: - Remove from Favorites
    func removeFavorite(_ article: Article, completion: @escaping (Bool) -> Void) {
        guard let articleId = article.articleId else {
            completion(false)
            return
        }

        let url = "https://yourapi.com/favorites/\(articleId)"

        AF.request(url, method: .delete).response { response in
            switch response.result {
            case .success:
                self.favorites.removeAll { $0.articleId == articleId }
                completion(true)
            case .failure(let error):
                print("Failed to remove favorite: \(error.localizedDescription)")
                completion(false)
            }
        }
    }

    // MARK: - Check if Favorite
    func isFavorite(_ article: Article) -> Bool {
        guard let articleId = article.articleId else { return false }
        return favorites.contains { $0.articleId == articleId }
    }

    // MARK: - Get Favorites
    func getFavorites() -> [Article] {
        return favorites
    }
}

