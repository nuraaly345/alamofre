import Alamofire
import Foundation

enum NetworkError: Error {
    case invalidURL
    case noData
    case unknown
}

class NetworkService {
    static let shared = NetworkService()
    
    private let apiKey = "pub_551426120912a4ad09123075121541c37b8de"
    private let baseURL = "https://newsdata.io/api/1"
    
    private init() {}

    func fetchTopHeadlines(nextPage: String?, completion: @escaping (Result<(articles: [Article], nextPage: String?), Error>) -> Void) {
        // Используем URLComponents для более безопасного формирования URL-строки.
        var components = URLComponents(string: "\(baseURL)/news")
        components?.queryItems = [
            URLQueryItem(name: "country", value: "us"),
            URLQueryItem(name: "language", value: "en"),
            URLQueryItem(name: "apikey", value: apiKey)
        ]
        
        if let nextPage = nextPage {
            components?.queryItems?.append(URLQueryItem(name: "page", value: nextPage))
        }
        
        guard let url = components?.url else {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        // Добавляем обработчик для логирования и отладки.
        print("Fetching headlines from: \(url.absoluteString)")
        
        AF.request(url)
            .validate(statusCode: 200..<300) // Валидация статуса ответа
            .responseDecodable(of: NewsResponse.self) { response in
                switch response.result {
                case .success(let newsResponse):
                    if newsResponse.status == "success" {
                        let articles = newsResponse.results
                        let nextPage = newsResponse.nextPage
                        completion(.success((articles: articles, nextPage: nextPage)))
                    } else {
                        completion(.failure(NetworkError.unknown))
                    }
                case .failure(let error):
                    print("Request failed with error: \(error)")
                    completion(.failure(error))
                }
            }
    }
}

