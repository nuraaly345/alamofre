import Foundation

class NewsDetailViewModel {
    var article: Article

    init(article: Article) {
        self.article = article
    }

    /// Метод для переключения состояния избранного.
    /// - Parameter completion: Замыкание с результатом операции (успех или ошибка).
    func toggleFavorite(completion: @escaping (Bool) -> Void) {
        if isFavorite() {
            removeArticleFromFavorites(completion: completion)
        } else {
            addArticleToFavorites(completion: completion)
        }
    }

    /// Проверка, является ли статья избранной.
    /// - Returns: `true` если статья находится в избранном, иначе `false`.
    func isFavorite() -> Bool {
        return FavoriteManager.shared.isFavorite(article)
    }

    /// Приватный метод для добавления статьи в избранное.
    /// - Parameter completion: Замыкание с результатом операции.
    private func addArticleToFavorites(completion: @escaping (Bool) -> Void) {
        FavoriteManager.shared.addFavorite(article) { success in
            completion(success)
        }
    }

    /// Приватный метод для удаления статьи из избранного.
    /// - Parameter completion: Замыкание с результатом операции.
    private func removeArticleFromFavorites(completion: @escaping (Bool) -> Void) {
        FavoriteManager.shared.removeFavorite(article) { success in
            completion(success)
        }
    }
}

