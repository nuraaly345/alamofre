import Foundation

class FavoritesViewModel {
    var articles: [Article] = []

    func loadFavorites() {
        articles = FavoriteManager.shared.getFavorites()
    }

    func removeFavorite(_ article: Article, completion: @escaping () -> Void) {
        // Используем слабую ссылку на self для избежания утечки памяти
        FavoriteManager.shared.removeFavorite(article) { [weak self] success in
            guard let self = self else {
                completion()
                return
            }

            if success {
                self.loadFavorites()
            } else {
                print("Failed to remove favorite")
            }
            completion()
        }
    }

    func addFavorite(_ article: Article, completion: @escaping (Bool) -> Void) {
        FavoriteManager.shared.addFavorite(article) { [weak self] success in
            guard let self = self else {
                completion(false)
                return
            }

            if success {
                self.loadFavorites()
                completion(true)
            } else {
                print("Failed to add favorite")
                completion(false)
            }
        }
    }
}

