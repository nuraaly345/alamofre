import Foundation
import Alamofire

class NewsListViewModel {
    var articles: [Article] = []
    var isLoading = false
    var error: Error?
    var nextPage: String? = nil // Начинаем с nil, что означает первую страницу

    private let baseURL = "https://newsdata.io/api/1/news"
    private let apiKey = "pub_551426120912a4ad09123075121541c37b8de"

    /// Метод для получения новостей
    func fetchNews(completion: @escaping () -> Void) {
        guard !isLoading else { return }
        isLoading = true

        // Создание URL с параметрами
        var parameters: [String: String] = [
            "country": "us",
            "language": "en",
            "apikey": apiKey
        ]
        
        if let nextPage = nextPage {
            parameters["page"] = nextPage
        }

        AF.request(baseURL, method: .get, parameters: parameters).responseDecodable(of: NewsResponse.self) { [weak self] response in
            guard let self = self else { return }
            self.isLoading = false

            switch response.result {
            case .success(let data):
                if data.status == "success" {
                    self.articles.append(contentsOf: data.results)
                    self.nextPage = data.nextPage
                    self.error = nil
                } else {
                    self.error = NetworkError.unknown
                }
                completion()
            case .failure(let error):
                self.error = error
                completion()
            }
        }
    }
}

