import Foundation
import UIKit
import SDWebImage

class NewsCell: UITableViewCell {
    private let newsImageView = UIImageView()
    private let titleLabel = UILabel()
    private let creatorLabel = UILabel()
    private let dateLabel = UILabel()

    private let labelsStackView = UIStackView()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    private func setupUI() {
        contentView.addSubview(newsImageView)
        contentView.addSubview(labelsStackView)

        newsImageView.translatesAutoresizingMaskIntoConstraints = false
        labelsStackView.translatesAutoresizingMaskIntoConstraints = false

        // Настройка newsImageView
        newsImageView.contentMode = .scaleAspectFill
        newsImageView.clipsToBounds = true
        newsImageView.layer.cornerRadius = 8  // Добавим скругленные углы для лучшего UX
        newsImageView.layer.masksToBounds = true

        // Настройка StackView для меток
        labelsStackView.axis = .vertical
        labelsStackView.spacing = 4

        labelsStackView.addArrangedSubview(titleLabel)
        labelsStackView.addArrangedSubview(creatorLabel)
        labelsStackView.addArrangedSubview(dateLabel)

        // Настройка шрифтов и цветов
        titleLabel.font = UIFont.boldSystemFont(ofSize: 16)
        titleLabel.numberOfLines = 2

        creatorLabel.font = UIFont.systemFont(ofSize: 14)
        creatorLabel.textColor = .secondaryLabel

        dateLabel.font = UIFont.systemFont(ofSize: 12)
        dateLabel.textColor = .tertiaryLabel

        // Ограничения для newsImageView
        NSLayoutConstraint.activate([
            newsImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            newsImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            newsImageView.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -8),
            newsImageView.widthAnchor.constraint(equalToConstant: 80),
            newsImageView.heightAnchor.constraint(equalToConstant: 80)
        ])

        // Ограничения для labelsStackView
        NSLayoutConstraint.activate([
            labelsStackView.leadingAnchor.constraint(equalTo: newsImageView.trailingAnchor, constant: 8),
            labelsStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            labelsStackView.centerYAnchor.constraint(equalTo: newsImageView.centerYAnchor),
            labelsStackView.topAnchor.constraint(greaterThanOrEqualTo: contentView.topAnchor, constant: 8),
            labelsStackView.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -8)
        ])
    }

    func configure(with article: Article) {
        titleLabel.text = article.title
        creatorLabel.text = article.creator?.first ?? "Неизвестный автор"
        dateLabel.text = formatDate(article.pubDate)

        if let imageUrlString = article.imageUrl, let imageUrl = URL(string: imageUrlString) {
            newsImageView.sd_setImage(with: imageUrl, placeholderImage: UIImage(systemName: "photo"), options: .highPriority, completed: nil)
        } else {
            newsImageView.image = UIImage(systemName: "photo")
        }
    }

    private func formatDate(_ dateString: String?) -> String {
        // Проверяем, что dateString не nil
        guard let dateString = dateString else {
            return ""
        }
        
        // Создаем объект DateFormatter для преобразования строки в дату
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss" // Формат входящей даты, проверьте соответствие вашим данным
        inputFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        // Пытаемся получить объект Date из строки
        if let date = inputFormatter.date(from: dateString) {
            // Создаем второй DateFormatter для преобразования даты в строку нужного формата
            let outputFormatter = DateFormatter()
            outputFormatter.dateStyle = .medium
            outputFormatter.timeStyle = .short
            outputFormatter.timeZone = TimeZone.current
            
            // Получаем строку с форматом даты для отображения
            return outputFormatter.string(from: date)
        } else {
            // Если не удалось преобразовать строку в дату, возвращаем оригинальную строку или пустую строку
            return dateString
        }
    }
}
