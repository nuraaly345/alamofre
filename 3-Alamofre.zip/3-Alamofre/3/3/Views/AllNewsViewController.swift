//
//  AllNewsViewController.swift
//  2
//
//  Created by zalkarbek on 2/10/24.
//

// Views/AllNewsViewController.swift

import UIKit

class AllNewsViewController: UIViewController {
    private let tableView = UITableView()
    private let viewModel = NewsListViewModel()
    private let refreshControl = UIRefreshControl()  // Добавлен RefreshControl для обновления

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        fetchNews()
    }

    private func setupUI() {
        title = "All News"
        view.backgroundColor = .systemBackground
        
        // Настройка таблицы
        view.addSubview(tableView)
        tableView.frame = view.bounds
        tableView.register(NewsCell.self, forCellReuseIdentifier: "NewsCell")
        tableView.delegate = self
        tableView.dataSource = self

        // Добавление refresh control
        refreshControl.addTarget(self, action: #selector(refreshNews), for: .valueChanged)
        tableView.refreshControl = refreshControl
    }

    @objc private func refreshNews() {
        viewModel.nextPage = nil  // Сбрасываем пагинацию
        viewModel.articles.removeAll()  // Убираем старые данные
        tableView.reloadData()
        fetchNews()
    }

    private func fetchNews() {
        // Добавляем индикатор загрузки внизу таблицы при пагинации
        if viewModel.isLoading && viewModel.nextPage != nil {
            tableView.tableFooterView = createLoadingFooterView()
        } else {
            tableView.tableFooterView = nil
        }

        viewModel.fetchNews { [weak self] in
            DispatchQueue.main.async {
                if let error = self?.viewModel.error {
                    self?.showErrorAlert(message: error.localizedDescription)
                } else {
                    self?.tableView.reloadData()
                }
                self?.refreshControl.endRefreshing()  // Заканчиваем обновление
                self?.tableView.tableFooterView = nil  // Убираем footer после окончания загрузки
            }
        }
    }

    private func createLoadingFooterView() -> UIView {
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 50))
        let spinner = UIActivityIndicatorView(style: .medium)
        spinner.center = footerView.center
        footerView.addSubview(spinner)
        spinner.startAnimating()
        return footerView
    }

    private func showErrorAlert(message: String) {
        let alert = UIAlertController(title: "Ошибка", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

extension AllNewsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.articles.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "NewsCell", for: indexPath) as? NewsCell else {
            return UITableViewCell()
        }
        let article = viewModel.articles[indexPath.row]
        cell.configure(with: article)
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let article = viewModel.articles[indexPath.row]
        let detailViewModel = NewsDetailViewModel(article: article)
        let detailVC = NewsDetailViewController(viewModel: detailViewModel)
        navigationController?.pushViewController(detailVC, animated: true)
    }

    // Пагинация
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let position = scrollView.contentOffset.y
        let threshold = tableView.contentSize.height - scrollView.frame.size.height - 100
        if position > threshold {
            guard !viewModel.isLoading, viewModel.nextPage != nil else { return }
            fetchNews()
        }
    }
}

